<!DOCTYPE html>
<html>
<head>
    <title>Add Data</title>
</head>
<body>
    <form action="add.php" method="post">
        <label>Name:</label><br>
        <input type="text" name="name" required><br>
        <label>Email:</label><br>
        <input type="email" name="email" required><br>
        <button type="submit" name="submit">Add Data</button>
    </form>
</body>
</html>
